/*
  # Add test responses

  1. Sample Data
    - Adds realistic test responses for both forms
    - Includes a mix of positive, neutral, and negative sentiments
    - Provides varied response patterns
*/

-- Customer Service Feedback responses
INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
    jsonb_build_object(
      'satisfaction', 'Very Satisfied',
      'improvement', 'The support team was excellent and resolved my issue quickly.',
      'recommend', 'Yes, definitely'
    )
  ),
  'positive',
  NOW() - interval '2 days';

INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
    jsonb_build_object(
      'satisfaction', 'Neutral',
      'improvement', 'Response time could be faster.',
      'recommend', 'Maybe'
    )
  ),
  'neutral',
  NOW() - interval '1 day';

INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Customer Service Feedback' LIMIT 1),
    jsonb_build_object(
      'satisfaction', 'Dissatisfied',
      'improvement', 'Had to wait too long for a response.',
      'recommend', 'No'
    )
  ),
  'negative',
  NOW() - interval '12 hours';

-- Product Feedback responses
INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
    jsonb_build_object(
      'product', 'Premium Headphones',
      'quality', 'Excellent',
      'comments', 'Great sound quality and comfortable to wear.'
    )
  ),
  'positive',
  NOW() - interval '3 days';

INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
    jsonb_build_object(
      'product', 'Wireless Mouse',
      'quality', 'Average',
      'comments', 'Battery life could be better.'
    )
  ),
  'neutral',
  NOW() - interval '1 day';

INSERT INTO responses (id, form_id, responses, sentiment, created_at)
SELECT 
  gen_random_uuid(),
  (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
  jsonb_build_object(
    (SELECT id FROM forms WHERE title = 'Product Feedback' LIMIT 1),
    jsonb_build_object(
      'product', 'Keyboard',
      'quality', 'Poor',
      'comments', 'Keys started sticking after a month.'
    )
  ),
  'negative',
  NOW() - interval '6 hours';