/*
  # Feedback Form Schema

  1. New Tables
    - forms
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - category (text)
      - fields (jsonb)
      - created_at (timestamp)
    - responses
      - id (uuid, primary key)
      - form_id (uuid, foreign key)
      - responses (jsonb)
      - sentiment (text)
      - created_at (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for public access (for demo purposes)
*/

-- Create forms table
CREATE TABLE IF NOT EXISTS forms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL,
  fields jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create responses table
CREATE TABLE IF NOT EXISTS responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_id uuid REFERENCES forms(id) ON DELETE CASCADE,
  responses jsonb NOT NULL,
  sentiment text CHECK (sentiment IN ('positive', 'negative', 'neutral')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE forms ENABLE ROW LEVEL SECURITY;
ALTER TABLE responses ENABLE ROW LEVEL SECURITY;

-- Create policies (public access for demo)
CREATE POLICY "Public can read forms"
  ON forms FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can insert forms"
  ON forms FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can read responses"
  ON responses FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can insert responses"
  ON responses FOR INSERT
  TO public
  WITH CHECK (true);