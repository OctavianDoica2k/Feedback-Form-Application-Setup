/*
  # Improve form deletion functionality

  1. Changes
    - Add audit logging for form deletions
    - Add soft delete capability
    - Add cleanup function for old soft-deleted forms

  2. Security
    - Enable RLS on the audit table
    - Add policies for audit access
*/

-- Create audit table for form deletions
CREATE TABLE IF NOT EXISTS form_deletion_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_id uuid NOT NULL,
  form_title text NOT NULL,
  deleted_at timestamptz DEFAULT now(),
  deleted_by uuid REFERENCES auth.users(id),
  response_count int NOT NULL,
  metadata jsonb
);

-- Enable RLS on audit table
ALTER TABLE form_deletion_audit ENABLE ROW LEVEL SECURITY;

-- Create policies for audit table
CREATE POLICY "Users can read their own audit logs"
  ON form_deletion_audit
  FOR SELECT
  TO authenticated
  USING (deleted_by = auth.uid());

-- Update form deletion trigger to include audit logging
CREATE OR REPLACE FUNCTION handle_form_deletion()
RETURNS TRIGGER AS $$
DECLARE
  response_count INT;
BEGIN
  -- Count responses before deletion
  SELECT COUNT(*) INTO response_count
  FROM responses
  WHERE form_id = OLD.id;

  -- Insert audit record
  INSERT INTO form_deletion_audit (
    form_id,
    form_title,
    deleted_by,
    response_count,
    metadata
  ) VALUES (
    OLD.id,
    OLD.title,
    auth.uid(),
    response_count,
    jsonb_build_object(
      'category', OLD.category,
      'field_count', jsonb_array_length(OLD.fields),
      'created_at', OLD.created_at
    )
  );

  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;