/*
  # Add missing database features

  This migration adds any missing features that aren't already present in the database.
  We use IF NOT EXISTS clauses to prevent errors on existing objects.
*/

-- Check if tables exist and create if they don't
CREATE TABLE IF NOT EXISTS forms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL,
  fields jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_id uuid REFERENCES forms(id) ON DELETE CASCADE,
  responses jsonb NOT NULL,
  sentiment text CHECK (sentiment IN ('positive', 'negative', 'neutral')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$ 
BEGIN
  -- Enable RLS on forms if not already enabled
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE tablename = 'forms' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE forms ENABLE ROW LEVEL SECURITY;
  END IF;

  -- Enable RLS on responses if not already enabled
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE tablename = 'responses' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE responses ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Create policies if they don't exist
DO $$ 
BEGIN
  -- Forms policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'forms' 
    AND policyname = 'Public can read forms'
  ) THEN
    CREATE POLICY "Public can read forms"
      ON forms FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'forms' 
    AND policyname = 'Public can insert forms'
  ) THEN
    CREATE POLICY "Public can insert forms"
      ON forms FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;

  -- Responses policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'responses' 
    AND policyname = 'Public can read responses'
  ) THEN
    CREATE POLICY "Public can read responses"
      ON responses FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'responses' 
    AND policyname = 'Public can insert responses'
  ) THEN
    CREATE POLICY "Public can insert responses"
      ON responses FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;
END $$;