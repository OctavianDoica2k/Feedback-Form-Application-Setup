/*
  # Fix Form Deletion

  1. Changes
    - Add trigger to ensure responses are deleted before form deletion
    - Add function to handle the deletion process
    - Ensure proper cleanup of related data

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity during deletion
*/

-- Create function to handle form deletion
CREATE OR REPLACE FUNCTION handle_form_deletion()
RETURNS TRIGGER AS $$
BEGIN
    -- Delete all responses for the form first
    DELETE FROM responses WHERE form_id = OLD.id;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to run before form deletion
DROP TRIGGER IF EXISTS before_form_delete ON forms;
CREATE TRIGGER before_form_delete
    BEFORE DELETE ON forms
    FOR EACH ROW
    EXECUTE FUNCTION handle_form_deletion();