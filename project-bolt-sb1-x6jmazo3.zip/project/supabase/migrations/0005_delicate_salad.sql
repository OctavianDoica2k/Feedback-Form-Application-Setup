/*
  # Fix Cascade Deletion

  1. Changes
    - Add proper cascade deletion for responses
    - Update foreign key constraint
    - Ensure data consistency
*/

-- Drop existing foreign key constraint if it exists
ALTER TABLE responses DROP CONSTRAINT IF EXISTS responses_form_id_fkey;

-- Add new foreign key constraint with CASCADE
ALTER TABLE responses 
  ADD CONSTRAINT responses_form_id_fkey 
  FOREIGN KEY (form_id) 
  REFERENCES forms(id) 
  ON DELETE CASCADE;