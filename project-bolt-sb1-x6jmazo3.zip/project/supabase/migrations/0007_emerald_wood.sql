/*
  # Add Delete Policy and Improve Form Deletion

  1. Changes
    - Add DELETE policy for forms table
    - Add DELETE policy for responses table
    - Update form deletion trigger for better error handling

  2. Security
    - Enable DELETE operations for public access (demo purposes)
    - Maintain RLS policies
*/

-- Add DELETE policies
DO $$ 
BEGIN
  -- Create DELETE policy for forms if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'forms' 
    AND policyname = 'Public can delete forms'
  ) THEN
    CREATE POLICY "Public can delete forms"
      ON forms FOR DELETE
      TO public
      USING (true);
  END IF;

  -- Create DELETE policy for responses if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'responses' 
    AND policyname = 'Public can delete responses'
  ) THEN
    CREATE POLICY "Public can delete responses"
      ON responses FOR DELETE
      TO public
      USING (true);
  END IF;
END $$;