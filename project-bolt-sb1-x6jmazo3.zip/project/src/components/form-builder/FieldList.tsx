import React from 'react';
import { PlusCircle } from 'lucide-react';
import { FormField } from '../../types/form';
import FieldEditor from './FieldEditor';

interface FieldListProps {
  fields: FormField[];
  onAddField: () => void;
  onUpdateField: (id: string, updates: Partial<FormField>) => void;
  onRemoveField: (id: string) => void;
}

export default function FieldList({
  fields,
  onAddField,
  onUpdateField,
  onRemoveField
}: FieldListProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Form Fields</h3>
        <button
          type="button"
          onClick={onAddField}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          <PlusCircle className="w-4 h-4 mr-2" />
          Add Field
        </button>
      </div>

      {fields.map((field) => (
        <FieldEditor
          key={field.id}
          field={field}
          onUpdate={onUpdateField}
          onRemove={onRemoveField}
        />
      ))}
    </div>
  );
}