import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { FormField } from '../../types/form';

interface ValidationProps {
  title: string;
  description: string;
  fields: FormField[];
}

export default function FormValidation({ title, description, fields }: ValidationProps) {
  const validations = [
    {
      check: 'title',
      passed: title.length >= 3,
      message: 'Title must be at least 3 characters long'
    },
    {
      check: 'description',
      passed: description.length >= 10,
      message: 'Description must be at least 10 characters long'
    },
    {
      check: 'fields',
      passed: fields.length >= 1,
      message: 'Form must have at least one field'
    },
    {
      check: 'fieldLabels',
      passed: fields.every(f => f.label.length >= 3),
      message: 'All field labels must be at least 3 characters long'
    },
    {
      check: 'fieldOptions',
      passed: fields.every(f => 
        !['select', 'radio'].includes(f.type) || 
        (f.options && f.options.length >= 2)
      ),
      message: 'Select and Radio fields must have at least 2 options'
    }
  ];

  const allPassed = validations.every(v => v.passed);

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Validation Status</h3>
      
      <div className="space-y-3">
        {validations.map(validation => (
          <div 
            key={validation.check}
            className="flex items-center space-x-2 text-sm"
          >
            {validation.passed ? (
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-500" />
            )}
            <span className={validation.passed ? 'text-green-700' : 'text-red-700'}>
              {validation.message}
            </span>
          </div>
        ))}
      </div>

      {!allPassed && (
        <div className="mt-4 text-sm text-gray-600">
          Please fix the validation issues before creating the form.
        </div>
      )}
    </div>
  );
}