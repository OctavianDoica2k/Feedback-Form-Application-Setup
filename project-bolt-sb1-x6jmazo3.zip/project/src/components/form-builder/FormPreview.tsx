import React from 'react';
import { FeedbackForm } from '../../types/form';
import FormField from '../form-renderer/FormField';

interface FormPreviewProps {
  form: Partial<FeedbackForm>;
}

export default function FormPreview({ form }: FormPreviewProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Preview</h3>
        <div className="text-sm text-gray-500">This is how your form will appear to users.</div>
      </div>

      <div className="border-2 border-dashed border-gray-200 rounded-lg p-6">
        <h2 className="text-2xl font-bold mb-2">{form.title || 'Untitled Form'}</h2>
        <p className="text-gray-600 mb-6">{form.description || 'No description provided'}</p>
        
        <div className="space-y-6">
          {form.fields?.map((field) => (
            <FormField
              key={field.id}
              field={field}
              value=""
              onChange={() => {}}
            />
          ))}
        </div>
      </div>
    </div>
  );
}