import React from 'react';
import { Trash2 } from 'lucide-react';
import { FormField } from '../../types/form';
import FieldOptions from './FieldOptions';

interface FieldEditorProps {
  field: FormField;
  onUpdate: (id: string, updates: Partial<FormField>) => void;
  onRemove: (id: string) => void;
}

export default function FieldEditor({ field, onUpdate, onRemove }: FieldEditorProps) {
  const showOptions = field.type === 'select' || field.type === 'radio';

  return (
    <div className="flex items-start space-x-4 p-4 border rounded-lg bg-white">
      <div className="flex-1 space-y-4">
        <input
          type="text"
          value={field.label}
          onChange={(e) => onUpdate(field.id, { label: e.target.value })}
          placeholder="Field Label"
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        
        <select
          value={field.type}
          onChange={(e) => onUpdate(field.id, { 
            type: e.target.value as FormField['type'],
            options: ['select', 'radio'].includes(e.target.value) ? [] : undefined
          })}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="text">Text</option>
          <option value="textarea">Text Area</option>
          <option value="select">Select</option>
          <option value="radio">Radio</option>
          <option value="checkbox">Checkbox</option>
        </select>

        {showOptions && (
          <div className="border-t pt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Field Options
            </label>
            <FieldOptions
              options={field.options || []}
              onChange={(options) => onUpdate(field.id, { options })}
            />
          </div>
        )}

        <label className="inline-flex items-center">
          <input
            type="checkbox"
            checked={field.required}
            onChange={(e) => onUpdate(field.id, { required: e.target.checked })}
            className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          <span className="ml-2 text-sm text-gray-600">Required</span>
        </label>
      </div>

      <button
        type="button"
        onClick={() => onRemove(field.id)}
        className="p-2 text-red-600 hover:text-red-800"
      >
        <Trash2 className="w-5 h-5" />
      </button>
    </div>
  );
}