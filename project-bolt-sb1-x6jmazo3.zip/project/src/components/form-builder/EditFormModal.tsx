import React, { useState } from 'react';
import { X } from 'lucide-react';
import { FeedbackForm } from '../../types/form';
import FormHeader from './FormHeader';
import FieldList from './FieldList';
import { useFormEdit } from '../../hooks/useFormEdit';

interface EditFormModalProps {
  form: FeedbackForm;
  isOpen: boolean;
  onClose: () => void;
}

export default function EditFormModal({ form, isOpen, onClose }: EditFormModalProps) {
  const [title, setTitle] = useState(form.title);
  const [description, setDescription] = useState(form.description);
  const [category, setCategory] = useState(form.category);
  const [fields, setFields] = useState(form.fields);
  
  const { loading, handleUpdate } = useFormEdit(form);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await handleUpdate(form.id, {
      title,
      description,
      category,
      fields
    });
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Edit Form</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <FormHeader
            title={title}
            description={description}
            category={category}
            onTitleChange={setTitle}
            onDescriptionChange={setDescription}
            onCategoryChange={setCategory}
          />

          <FieldList
            fields={fields}
            onAddField={() => setFields([...fields, {
              id: crypto.randomUUID(),
              type: 'text',
              label: '',
              required: false
            }])}
            onUpdateField={(id, updates) => {
              setFields(fields.map(field =>
                field.id === id ? { ...field, ...updates } : field
              ));
            }}
            onRemoveField={(id) => {
              setFields(fields.filter(field => field.id !== id));
            }}
          />

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}