import React, { useState } from 'react';
import { FeedbackForm, FeedbackResponse } from '../types/form';
import { useFormStore } from '../store/formStore';
import { getSentimentFromResponse } from '../utils/sentiment';
import FormField from './form-renderer/FormField';

interface Props {
  form: FeedbackForm;
}

export default function FormRenderer({ form }: Props) {
  const addResponse = useFormStore(state => state.addResponse);
  const [responses, setResponses] = useState<Record<string, any>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const feedbackResponse: FeedbackResponse = {
      id: crypto.randomUUID(),
      formId: form.id,
      responses,
      sentiment: getSentimentFromResponse(form, responses),
      createdAt: new Date().toISOString()
    };
    
    addResponse(feedbackResponse);
    setResponses({});
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-2">{form.title}</h2>
      <p className="text-gray-600 mb-6">{form.description}</p>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {form.fields.map((field) => (
          <FormField
            key={field.id}
            field={field}
            value={responses[field.id]}
            onChange={(value) => setResponses({ ...responses, [field.id]: value })}
          />
        ))}
        
        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            Submit Feedback
          </button>
        </div>
      </form>
    </div>
  );
}