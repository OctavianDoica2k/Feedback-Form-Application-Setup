import React from 'react';
import { Bar } from 'react-chartjs-2';
import { FeedbackForm, FeedbackResponse } from '../../types/form';
import { defaultOptions } from './ChartConfig';

interface Props {
  forms: FeedbackForm[];
  responses: FeedbackResponse[];
}

export default function CompletionRates({ forms, responses }: Props) {
  const completionData = forms.map(form => {
    const formResponses = responses.filter(r => r.formId === form.id);
    const avgCompletion = formResponses.length > 0
      ? formResponses.reduce((acc, r) => 
          acc + (Object.keys(r.responses).length / form.fields.length) * 100, 
        0) / formResponses.length
      : 0;
    
    return {
      title: form.title,
      rate: Math.round(avgCompletion)
    };
  });

  const data = {
    labels: completionData.map(d => d.title),
    datasets: [{
      label: 'Average Completion Rate (%)',
      data: completionData.map(d => d.rate),
      backgroundColor: 'rgba(147, 51, 234, 0.6)',
      borderColor: 'rgb(147, 51, 234)',
      borderWidth: 1
    }]
  };

  const options = {
    ...defaultOptions,
    plugins: {
      ...defaultOptions.plugins,
      title: {
        display: true,
        text: 'Form Completion Rates'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: (value: number) => `${value}%`
        }
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow h-[400px]">
      <Bar data={data} options={options} />
    </div>
  );
}