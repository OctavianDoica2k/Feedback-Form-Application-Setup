import React from 'react';
import { FeedbackForm, FeedbackResponse } from '../../../types/form';
import { formatDate } from '../../../utils/date';
import ResponseAnswers from './ResponseAnswers';

interface ResponseDetailsTableProps {
  form: FeedbackForm | null;
  responses: FeedbackResponse[];
}

export default function ResponseDetailsTable({ form, responses }: ResponseDetailsTableProps) {
  if (!responses.length) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <p className="text-gray-500 text-center">No responses yet</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b">
        <h3 className="text-lg font-semibold text-gray-900">Detailed Responses</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Answers
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Sentiment
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {responses.map((response) => (
              <tr key={response.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDate(response.createdAt)}
                </td>
                <td className="px-6 py-4">
                  <ResponseAnswers form={form} response={response} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${response.sentiment === 'positive' ? 'bg-green-100 text-green-800' : ''}
                    ${response.sentiment === 'neutral' ? 'bg-yellow-100 text-yellow-800' : ''}
                    ${response.sentiment === 'negative' ? 'bg-red-100 text-red-800' : ''}`}
                  >
                    {response.sentiment.charAt(0).toUpperCase() + response.sentiment.slice(1)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}