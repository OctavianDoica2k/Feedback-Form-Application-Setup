import React from 'react';
import { FeedbackForm, FeedbackResponse } from '../../../types/form';

interface ResponseAnswersProps {
  form: FeedbackForm | null;
  response: FeedbackResponse;
}

export default function ResponseAnswers({ form, response }: ResponseAnswersProps) {
  if (!form) {
    return (
      <div className="space-y-2">
        {Object.entries(response.responses).map(([fieldId, answer]) => (
          <div key={fieldId} className="text-sm">
            <span className="font-medium text-gray-900">{fieldId}:</span>{' '}
            <span className="text-gray-500">{formatAnswer(answer)}</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {form.fields.map(field => (
        <div key={field.id} className="text-sm">
          <span className="font-medium text-gray-900">{field.label}:</span>{' '}
          <span className="text-gray-500">
            {formatAnswer(response.responses[field.id])}
          </span>
        </div>
      ))}
    </div>
  );
}

function formatAnswer(answer: any): string {
  if (answer === undefined || answer === null) return 'Not answered';
  if (typeof answer === 'boolean') return answer ? 'Yes' : 'No';
  return String(answer);
}