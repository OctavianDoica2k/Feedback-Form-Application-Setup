import React from 'react';
import { Bar } from 'react-chartjs-2';
import { FeedbackForm, FeedbackResponse } from '../../types/form';
import { defaultOptions } from './ChartConfig';

interface Props {
  forms: FeedbackForm[];
  responses: FeedbackResponse[];
}

export default function CategoryDistribution({ forms, responses }: Props) {
  const categories = [...new Set(forms.map(form => form.category))];
  
  const data = {
    labels: categories,
    datasets: [{
      label: 'Responses by Category',
      data: categories.map(category => 
        responses.filter(r => 
          forms.find(f => f.id === r.formId)?.category === category
        ).length
      ),
      backgroundColor: 'rgba(54, 162, 235, 0.6)',
      borderColor: 'rgb(54, 162, 235)',
      borderWidth: 1
    }]
  };

  const options = {
    ...defaultOptions,
    plugins: {
      ...defaultOptions.plugins,
      title: {
        display: true,
        text: 'Response Distribution by Category'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1
        }
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow h-[400px]">
      <Bar data={data} options={options} />
    </div>
  );
}