import React from 'react';
import { FeedbackForm } from '../../types/form';

interface FormSelectorProps {
  forms: FeedbackForm[];
  selectedFormId: string | null;
  onSelectForm: (formId: string | null) => void;
}

export default function FormSelector({ forms, selectedFormId, onSelectForm }: FormSelectorProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow mb-6">
      <label htmlFor="form-select" className="block text-sm font-medium text-gray-700 mb-2">
        Select Form to Analyze
      </label>
      <select
        id="form-select"
        value={selectedFormId || ''}
        onChange={(e) => onSelectForm(e.target.value || null)}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
      >
        <option value="">All Forms</option>
        {forms.map((form) => (
          <option key={form.id} value={form.id}>
            {form.title}
          </option>
        ))}
      </select>
    </div>
  );
}