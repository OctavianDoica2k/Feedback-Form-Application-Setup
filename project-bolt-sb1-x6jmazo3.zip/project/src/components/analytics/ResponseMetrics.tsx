import React from 'react';
import { Clock, Users, CheckSquare } from 'lucide-react';
import { FeedbackForm, FeedbackResponse } from '../../types/form';

interface Props {
  forms: FeedbackForm[];
  responses: FeedbackResponse[];
}

export default function ResponseMetrics({ forms, responses }: Props) {
  const totalResponses = responses.length;
  const averageResponsesPerForm = Math.round(totalResponses / forms.length);
  const completionRate = Math.round(
    (responses.reduce((acc, r) => 
      acc + (Object.keys(r.responses).length / 
        forms.find(f => f.id === r.formId)?.fields.length || 1), 
    0) / responses.length) * 100
  );

  const metrics = [
    {
      label: 'Total Responses',
      value: totalResponses,
      icon: Users,
      color: 'text-blue-600'
    },
    {
      label: 'Avg Responses per Form',
      value: averageResponsesPerForm,
      icon: Clock,
      color: 'text-purple-600'
    },
    {
      label: 'Overall Completion Rate',
      value: `${completionRate}%`,
      icon: CheckSquare,
      color: 'text-green-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {metrics.map(metric => (
        <div key={metric.label} className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <metric.icon className={`w-12 h-12 ${metric.color}`} />
            <div className="ml-4">
              <div className="text-2xl font-bold">{metric.value}</div>
              <div className="text-sm text-gray-600">{metric.label}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}