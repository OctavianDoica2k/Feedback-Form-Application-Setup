import React from 'react';
import { FeedbackForm, FeedbackResponse } from '../../types/form';
import { useFormStats } from './hooks/useFormStats';
import { formatDuration } from '../../utils/date';

interface Props {
  forms: FeedbackForm[];
  responses: FeedbackResponse[];
}

export default function FormStatsTable({ forms, responses }: Props) {
  const stats = useFormStats(forms, responses);

  return (
    <div className="bg-white p-6 rounded-lg shadow overflow-hidden">
      <h3 className="text-lg font-semibold mb-4">Detailed Form Statistics</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Form</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Responses</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Completion Rate</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Time Between</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sentiment</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {stats.map(stat => (
              <tr key={stat.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{stat.title}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{stat.category}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{stat.totalResponses}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{stat.completionRate}%</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {stat.avgTimeBetweenResponses ? formatDuration(stat.avgTimeBetweenResponses) : 'N/A'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {stat.sentiments.positive}
                    </span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      {stat.sentiments.neutral}
                    </span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      {stat.sentiments.negative}
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}