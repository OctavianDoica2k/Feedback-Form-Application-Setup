import React from 'react';
import { Pie } from 'react-chartjs-2';
import { FeedbackResponse } from '../../types/form';
import { defaultOptions } from './ChartConfig';

interface Props {
  responses: FeedbackResponse[];
}

export default function SentimentOverview({ responses }: Props) {
  const sentimentCounts = {
    positive: responses.filter(r => r.sentiment === 'positive').length,
    neutral: responses.filter(r => r.sentiment === 'neutral').length,
    negative: responses.filter(r => r.sentiment === 'negative').length
  };

  const data = {
    labels: ['Positive', 'Neutral', 'Negative'],
    datasets: [{
      data: [sentimentCounts.positive, sentimentCounts.neutral, sentimentCounts.negative],
      backgroundColor: [
        'rgba(75, 192, 192, 0.6)',
        'rgba(255, 206, 86, 0.6)',
        'rgba(255, 99, 132, 0.6)'
      ],
      borderColor: [
        'rgb(75, 192, 192)',
        'rgb(255, 206, 86)',
        'rgb(255, 99, 132)'
      ],
      borderWidth: 1
    }]
  };

  const options = {
    ...defaultOptions,
    plugins: {
      ...defaultOptions.plugins,
      title: {
        display: true,
        text: 'Sentiment Distribution'
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="h-[300px]">
        <Pie data={data} options={options} />
      </div>
      <div className="mt-4 grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-2xl font-bold text-emerald-600">{sentimentCounts.positive}</div>
          <div className="text-sm text-gray-600">Positive</div>
        </div>
        <div>
          <div className="text-2xl font-bold text-yellow-600">{sentimentCounts.neutral}</div>
          <div className="text-sm text-gray-600">Neutral</div>
        </div>
        <div>
          <div className="text-2xl font-bold text-red-600">{sentimentCounts.negative}</div>
          <div className="text-sm text-gray-600">Negative</div>
        </div>
      </div>
    </div>
  );
}