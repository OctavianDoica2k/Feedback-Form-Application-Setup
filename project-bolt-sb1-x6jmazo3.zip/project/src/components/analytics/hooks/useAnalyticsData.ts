import { useMemo } from 'react';
import { FeedbackForm, FeedbackResponse } from '../../../types/form';
import { groupByDate } from '../../../utils/date';

export function useAnalyticsData(forms: FeedbackForm[], responses: FeedbackResponse[]) {
  return useMemo(() => {
    const responsesByDate = groupByDate(responses, r => r.createdAt);
    const completionRates = forms.map(form => ({
      formId: form.id,
      title: form.title,
      totalFields: form.fields.length,
      responses: responses.filter(r => r.formId === form.id).map(r => ({
        completedFields: Object.keys(r.responses).length,
        percentage: (Object.keys(r.responses).length / form.fields.length) * 100
      }))
    }));

    const averageResponseTime = forms.map(form => {
      const formResponses = responses.filter(r => r.formId === form.id);
      if (formResponses.length < 2) return null;
      
      const sortedDates = formResponses
        .map(r => new Date(r.createdAt).getTime())
        .sort((a, b) => a - b);
      
      const intervals = sortedDates
        .slice(1)
        .map((date, i) => date - sortedDates[i]);
      
      return {
        formId: form.id,
        title: form.title,
        averageInterval: intervals.reduce((a, b) => a + b, 0) / intervals.length
      };
    }).filter(Boolean);

    return {
      responsesByDate,
      completionRates,
      averageResponseTime
    };
  }, [forms, responses]);
}