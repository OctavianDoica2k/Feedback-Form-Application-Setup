import { useMemo } from 'react';
import { FeedbackResponse } from '../../../types/form';

export function useSentimentTrends(responses: FeedbackResponse[]) {
  return useMemo(() => {
    const sortedResponses = [...responses].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );

    const trends = sortedResponses.reduce((acc, response) => {
      const date = new Date(response.createdAt).toLocaleDateString();
      if (!acc[date]) {
        acc[date] = { positive: 0, neutral: 0, negative: 0 };
      }
      acc[date][response.sentiment]++;
      return acc;
    }, {} as Record<string, Record<string, number>>);

    return {
      labels: Object.keys(trends),
      datasets: [
        {
          label: 'Positive',
          data: Object.values(trends).map(d => d.positive),
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.5)',
        },
        {
          label: 'Neutral',
          data: Object.values(trends).map(d => d.neutral),
          borderColor: 'rgb(255, 206, 86)',
          backgroundColor: 'rgba(255, 206, 86, 0.5)',
        },
        {
          label: 'Negative',
          data: Object.values(trends).map(d => d.negative),
          borderColor: 'rgb(255, 99, 132)',
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
        }
      ]
    };
  }, [responses]);
}