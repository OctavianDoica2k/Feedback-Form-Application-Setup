import { useMemo } from 'react';
import { FeedbackForm, FeedbackResponse } from '../../../types/form';

export function useFormStats(forms: FeedbackForm[], responses: FeedbackResponse[]) {
  return useMemo(() => {
    return forms.map(form => {
      const formResponses = responses.filter(r => r.formId === form.id);
      
      // Calculate completion rate
      const avgCompletion = formResponses.length > 0
        ? formResponses.reduce((acc, r) => 
            acc + (Object.keys(r.responses).length / form.fields.length) * 100, 
          0) / formResponses.length
        : 0;

      // Calculate average time between responses
      const sortedDates = formResponses
        .map(r => new Date(r.createdAt).getTime())
        .sort((a, b) => a - b);
      
      const avgTimeBetweenResponses = sortedDates.length > 1
        ? sortedDates
            .slice(1)
            .reduce((acc, date, i) => acc + (date - sortedDates[i]), 0) / (sortedDates.length - 1)
        : 0;

      return {
        id: form.id,
        title: form.title,
        category: form.category,
        totalResponses: formResponses.length,
        completionRate: Math.round(avgCompletion),
        avgTimeBetweenResponses,
        sentiments: {
          positive: formResponses.filter(r => r.sentiment === 'positive').length,
          neutral: formResponses.filter(r => r.sentiment === 'neutral').length,
          negative: formResponses.filter(r => r.sentiment === 'negative').length
        }
      };
    });
  }, [forms, responses]);
}