import React from 'react';
import { Line } from 'react-chartjs-2';
import { FeedbackResponse } from '../../types/form';
import { defaultOptions } from './ChartConfig';
import { useSentimentTrends } from './hooks/useSentimentTrends';

interface Props {
  responses: FeedbackResponse[];
}

export default function SentimentTrends({ responses }: Props) {
  const chartData = useSentimentTrends(responses);
  
  const options = {
    ...defaultOptions,
    plugins: {
      ...defaultOptions.plugins,
      title: {
        display: true,
        text: 'Sentiment Trends Over Time'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        stacked: true
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow h-[400px]">
      <Line data={chartData} options={options} />
    </div>
  );
}