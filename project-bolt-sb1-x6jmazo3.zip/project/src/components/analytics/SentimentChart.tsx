import React from 'react';
import { Pie } from 'react-chartjs-2';
import { FeedbackResponse } from '../../types/form';

interface Props {
  responses: FeedbackResponse[];
}

export default function SentimentChart({ responses }: Props) {
  const data = {
    labels: ['Positive', 'Neutral', 'Negative'],
    datasets: [{
      data: [
        responses.filter(r => r.sentiment === 'positive').length,
        responses.filter(r => r.sentiment === 'neutral').length,
        responses.filter(r => r.sentiment === 'negative').length
      ],
      backgroundColor: [
        'rgba(75, 192, 192, 0.6)',
        'rgba(255, 206, 86, 0.6)',
        'rgba(255, 99, 132, 0.6)'
      ]
    }]
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4">Sentiment Distribution</h3>
      <Pie data={data} />
    </div>
  );
}