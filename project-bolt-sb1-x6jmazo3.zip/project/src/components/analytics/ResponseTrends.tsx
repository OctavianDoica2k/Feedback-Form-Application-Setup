import React from 'react';
import { Line } from 'react-chartjs-2';
import { groupByDate } from '../../utils/date';
import { FeedbackResponse } from '../../types/form';
import { defaultOptions } from './ChartConfig';

interface Props {
  responses: FeedbackResponse[];
}

export default function ResponseTrends({ responses }: Props) {
  const responsesByDate = groupByDate(responses, r => r.createdAt);
  
  const data = {
    labels: Object.keys(responsesByDate),
    datasets: [{
      label: 'Responses Over Time',
      data: Object.values(responsesByDate),
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1,
      fill: false
    }]
  };

  const options = {
    ...defaultOptions,
    plugins: {
      ...defaultOptions.plugins,
      title: {
        display: true,
        text: 'Response Trends Over Time'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1
        }
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow h-[400px]">
      <Line data={data} options={options} />
    </div>
  );
}