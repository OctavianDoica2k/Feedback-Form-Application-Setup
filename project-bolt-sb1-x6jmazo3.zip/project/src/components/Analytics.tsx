import React, { useState } from 'react';
import { useFormStore } from '../store/formStore';
import ResponseMetrics from './analytics/ResponseMetrics';
import SentimentOverview from './analytics/SentimentOverview';
import CategoryDistribution from './analytics/CategoryDistribution';
import ResponseTrends from './analytics/ResponseTrends';
import SentimentTrends from './analytics/SentimentTrends';
import FormStatsTable from './analytics/FormStatsTable';
import FormSelector from './analytics/FormSelector';
import ResponseDetailsTable from './analytics/responses/ResponseDetailsTable';
import { useFilteredResponses } from '../hooks/useFilteredResponses';

export default function Analytics() {
  const { forms, responses } = useFormStore();
  const [selectedFormId, setSelectedFormId] = useState<string | null>(null);
  const filteredResponses = useFilteredResponses(responses, selectedFormId);

  if (!forms.length) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900">No Data Available</h2>
        <p className="mt-2 text-gray-600">Create some forms to start collecting feedback.</p>
      </div>
    );
  }

  const selectedForm = selectedFormId ? forms.find(f => f.id === selectedFormId) : null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">
          {selectedForm ? `Analytics: ${selectedForm.title}` : 'Overall Analytics'}
        </h2>
      </div>

      <FormSelector
        forms={forms}
        selectedFormId={selectedFormId}
        onSelectForm={setSelectedFormId}
      />
      
      <ResponseMetrics
        forms={selectedForm ? [selectedForm] : forms}
        responses={filteredResponses}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SentimentOverview responses={filteredResponses} />
        <CategoryDistribution
          forms={selectedForm ? [selectedForm] : forms}
          responses={filteredResponses}
        />
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        <SentimentTrends responses={filteredResponses} />
        <ResponseTrends responses={filteredResponses} />
      </div>
      
      <ResponseDetailsTable
        form={selectedForm}
        responses={filteredResponses}
      />
      
      <FormStatsTable
        forms={selectedForm ? [selectedForm] : forms}
        responses={filteredResponses}
      />
    </div>
  );
}