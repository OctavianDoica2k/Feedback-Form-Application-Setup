import React from 'react';
import { FormField as IFormField } from '../../types/form';

interface FormFieldProps {
  field: IFormField;
  value: any;
  onChange: (value: any) => void;
}

export default function FormField({ field, value, onChange }: FormFieldProps) {
  const renderField = () => {
    switch (field.type) {
      case 'text':
        return (
          <input
            type="text"
            required={field.required}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        );
      
      case 'textarea':
        return (
          <textarea
            required={field.required}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            rows={4}
          />
        );
      
      case 'select':
        return (
          <select
            required={field.required}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select an option</option>
            {field.options?.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );
      
      case 'radio':
        return (
          <div className="mt-2 space-y-2">
            {field.options?.map((option) => (
              <label key={option} className="inline-flex items-center">
                <input
                  type="radio"
                  required={field.required}
                  name={field.id}
                  value={option}
                  checked={value === option}
                  onChange={(e) => onChange(e.target.value)}
                  className="form-radio text-blue-600"
                />
                <span className="ml-2">{option}</span>
              </label>
            ))}
          </div>
        );
      
      case 'checkbox':
        return (
          <div className="mt-2">
            <input
              type="checkbox"
              required={field.required}
              checked={value || false}
              onChange={(e) => onChange(e.target.checked)}
              className="form-checkbox text-blue-600"
            />
          </div>
        );
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {field.label}
        {field.required && <span className="text-red-500 ml-1">*</span>}
      </label>
      {renderField()}
    </div>
  );
}