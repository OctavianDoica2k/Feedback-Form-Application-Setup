import React, { useState } from 'react';
import { Pencil, Trash2, BarChart3, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useFormActions } from '../hooks/useFormActions';
import DeleteConfirmationModal from './DeleteConfirmationModal';

interface FormActionsProps {
  formId: string;
  formTitle: string;
  onEdit: () => void;
}

export default function FormActions({ formId, formTitle, onEdit }: FormActionsProps) {
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const { isDeleting, handleDelete } = useFormActions();

  const onConfirmDelete = async () => {
    await handleDelete(formId, formTitle);
    setShowDeleteModal(false);
  };

  return (
    <>
      <div className="flex space-x-2">
        <button
          onClick={onEdit}
          className="p-2 text-blue-600 hover:text-blue-800 transition-colors"
          title="Edit form"
        >
          <Pencil className="w-5 h-5" />
        </button>
        
        <Link
          to={`/analytics?form=${formId}`}
          className="p-2 text-purple-600 hover:text-purple-800 transition-colors"
          title="View analytics"
        >
          <BarChart3 className="w-5 h-5" />
        </Link>
        
        <button
          onClick={() => setShowDeleteModal(true)}
          disabled={isDeleting}
          className="p-2 text-red-600 hover:text-red-800 transition-colors disabled:opacity-50"
          title="Delete form"
        >
          {isDeleting ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Trash2 className="w-5 h-5" />
          )}
        </button>
      </div>

      <DeleteConfirmationModal
        isOpen={showDeleteModal}
        formTitle={formTitle}
        onConfirm={onConfirmDelete}
        onCancel={() => setShowDeleteModal(false)}
        isLoading={isDeleting}
      />
    </>
  );
}