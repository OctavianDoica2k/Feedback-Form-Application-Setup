import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FeedbackForm } from '../types/form';
import FormActions from './FormActions';
import EditFormModal from './form-builder/EditFormModal';

interface FormCardProps {
  form: FeedbackForm;
}

export default function FormCard({ form }: FormCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{form.title}</h3>
            <p className="mt-2 text-gray-600">{form.description}</p>
            <span className="mt-4 inline-block px-2 py-1 text-sm font-medium text-blue-700 bg-blue-100 rounded-full">
              {form.category}
            </span>
          </div>
          <FormActions
            formId={form.id}
            formTitle={form.title}
            onEdit={() => setIsEditModalOpen(true)}
          />
        </div>
        
        <div className="mt-4 pt-4 border-t">
          <Link
            to={`/form/${form.id}`}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
          >
            View Form →
          </Link>
        </div>
      </div>

      <EditFormModal
        form={form}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
    </>
  );
}