import React, { useState } from 'react';
import { FormField } from '../types/form';
import { useFormStore } from '../store/formStore';
import FormHeader from './form-builder/FormHeader';
import FieldList from './form-builder/FieldList';
import FormPreview from './form-builder/FormPreview';
import FormValidation from './form-builder/FormValidation';
import { validateFormFields, createNewField, createNewForm } from '../utils/form';

export default function FormBuilder() {
  const addForm = useFormStore(state => state.addForm);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [fields, setFields] = useState<FormField[]>([]);
  const [showPreview, setShowPreview] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateFormFields(fields)) {
      alert('Please fix the validation issues before creating the form');
      return;
    }

    const newForm = createNewForm(title, description, category, fields);
    addForm(newForm);
    
    // Reset form
    setTitle('');
    setDescription('');
    setCategory('');
    setFields([]);
    setShowPreview(false);
  };

  const previewForm = {
    title,
    description,
    category,
    fields,
    id: 'preview',
    createdAt: new Date().toISOString()
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Create Feedback Form</h2>
        <button
          type="button"
          onClick={() => setShowPreview(!showPreview)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
        >
          {showPreview ? 'Hide Preview' : 'Show Preview'}
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <FormHeader
              title={title}
              description={description}
              category={category}
              onTitleChange={setTitle}
              onDescriptionChange={setDescription}
              onCategoryChange={setCategory}
            />

            <FieldList
              fields={fields}
              onAddField={() => setFields([...fields, createNewField()])}
              onUpdateField={(id, updates) => {
                setFields(fields.map(field => 
                  field.id === id ? { ...field, ...updates } : field
                ));
              }}
              onRemoveField={(id) => {
                setFields(fields.filter(field => field.id !== id));
              }}
            />

            <FormValidation
              title={title}
              description={description}
              fields={fields}
            />

            <div className="flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                Create Form
              </button>
            </div>
          </form>
        </div>

        {showPreview && (
          <div className="lg:sticky lg:top-6 space-y-6">
            <FormPreview form={previewForm} />
          </div>
        )}
      </div>
    </div>
  );
}