import { create } from 'zustand';
import { FeedbackForm, FeedbackResponse } from '../types/form';
import { supabase } from '../lib/supabase';
import { mapDbToForm, mapFormToDb, mapDbToResponse, mapResponseToDb } from '../utils/mappers';

interface FormStore {
  forms: FeedbackForm[];
  responses: FeedbackResponse[];
  loading: boolean;
  error: string | null;
  fetchForms: () => Promise<void>;
  fetchResponses: () => Promise<void>;
  addForm: (form: FeedbackForm) => Promise<void>;
  updateForm: (id: string, updates: Partial<FeedbackForm>) => Promise<void>;
  deleteForm: (id: string) => Promise<void>;
  addResponse: (response: FeedbackResponse) => Promise<void>;
  getFormById: (id: string) => FeedbackForm | undefined;
  getResponsesByFormId: (formId: string) => FeedbackResponse[];
  clearError: () => void;
}

export const useFormStore = create<FormStore>((set, get) => ({
  forms: [],
  responses: [],
  loading: false,
  error: null,

  clearError: () => set({ error: null }),

  fetchForms: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase
        .from('forms')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const mappedForms = data.map(mapDbToForm);
      set({ forms: mappedForms });
    } catch (error) {
      set({ error: (error as Error).message });
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  deleteForm: async (id) => {
    const previousForms = get().forms;
    const previousResponses = get().responses;

    try {
      // Optimistic update
      set({
        forms: previousForms.filter(f => f.id !== id),
        responses: previousResponses.filter(r => r.formId !== id)
      });

      const { error } = await supabase
        .from('forms')
        .delete()
        .eq('id', id);

      if (error) throw error;

    } catch (error) {
      // Rollback on error
      set({
        forms: previousForms,
        responses: previousResponses,
        error: (error as Error).message
      });
      throw error;
    }
  },

  fetchResponses: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase
        .from('responses')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const mappedResponses = data.map(mapDbToResponse);
      set({ responses: mappedResponses });
    } catch (error) {
      set({ error: (error as Error).message });
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  addForm: async (form) => {
    set({ loading: true, error: null });
    try {
      const dbForm = mapFormToDb(form);
      const { error } = await supabase
        .from('forms')
        .insert([dbForm]);

      if (error) throw error;
      
      const { forms } = get();
      set({ forms: [form, ...forms] });
    } catch (error) {
      set({ error: (error as Error).message });
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  updateForm: async (id, updates) => {
    set({ loading: true, error: null });
    try {
      const { error } = await supabase
        .from('forms')
        .update(mapFormToDb(updates as FeedbackForm))
        .eq('id', id);

      if (error) throw error;

      const { forms } = get();
      set({
        forms: forms.map(form =>
          form.id === id ? { ...form, ...updates } : form
        )
      });
    } catch (error) {
      set({ error: (error as Error).message });
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  addResponse: async (response) => {
    set({ loading: true, error: null });
    try {
      const dbResponse = mapResponseToDb(response);
      const { error } = await supabase
        .from('responses')
        .insert([dbResponse]);

      if (error) throw error;
      
      const { responses } = get();
      set({ responses: [response, ...responses] });
    } catch (error) {
      set({ error: (error as Error).message });
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  getFormById: (id) => {
    const { forms } = get();
    return forms.find(form => form.id === id);
  },

  getResponsesByFormId: (formId) => {
    const { responses } = get();
    return responses.filter(response => response.formId === formId);
  }
}));