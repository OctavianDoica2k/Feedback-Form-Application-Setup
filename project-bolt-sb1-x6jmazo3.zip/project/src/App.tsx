import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { LayoutGrid, FileInput, BarChart3 } from 'lucide-react';
import FormBuilder from './components/FormBuilder';
import FormRenderer from './components/FormRenderer';
import Analytics from './components/Analytics';
import FormCard from './components/FormCard';
import { useFormStore } from './store/formStore';
import { seedTestData } from './data/testData';
import { FeedbackForm } from './types/form';

export default function App() {
  const store = useFormStore();
  const { forms } = store;
  const [editingForm, setEditingForm] = React.useState<FeedbackForm | null>(null);

  useEffect(() => {
    const initializeData = async () => {
      try {
        await store.fetchForms();
        await store.fetchResponses();

        // Seed test data if no forms exist
        if (forms.length === 0) {
          await seedTestData();
          // Refresh forms after seeding
          await store.fetchForms();
        }
      } catch (error) {
        console.error('Error initializing data:', error);
      }
    };

    initializeData();
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <nav className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex space-x-8">
                <Link to="/" className="inline-flex items-center px-1 pt-1 text-gray-900">
                  <LayoutGrid className="w-5 h-5 mr-2" />
                  Forms
                </Link>
                <Link to="/create" className="inline-flex items-center px-1 pt-1 text-gray-900">
                  <FileInput className="w-5 h-5 mr-2" />
                  Create Form
                </Link>
                <Link to="/analytics" className="inline-flex items-center px-1 pt-1 text-gray-900">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Analytics
                </Link>
              </div>
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <Routes>
            <Route path="/" element={
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {forms.map(form => (
                  <FormCard
                    key={form.id}
                    form={form}
                    onEdit={() => setEditingForm(form)}
                  />
                ))}
              </div>
            } />
            <Route path="/create" element={
              <FormBuilder
                initialForm={editingForm}
                onComplete={() => setEditingForm(null)}
              />
            } />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/form/:id" element={
              <FormRenderer form={forms[0]} />
            } />
          </Routes>
        </main>
      </div>
    </Router>
  );
}