import { useMemo } from 'react';
import { FeedbackResponse } from '../types/form';

export function useFilteredResponses(responses: FeedbackResponse[], selectedFormId: string | null) {
  return useMemo(() => {
    if (!selectedFormId) return responses;
    return responses.filter(response => response.formId === selectedFormId);
  }, [responses, selectedFormId]);
}