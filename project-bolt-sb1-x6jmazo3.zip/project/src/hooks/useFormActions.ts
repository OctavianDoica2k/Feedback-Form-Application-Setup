import { useState } from 'react';
import { useFormStore } from '../store/formStore';
import { toast } from '../utils/toast';
import { useNavigate } from 'react-router-dom';

export function useFormActions() {
  const [isDeleting, setIsDeleting] = useState(false);
  const deleteForm = useFormStore(state => state.deleteForm);
  const navigate = useNavigate();

  const handleDelete = async (id: string, title: string) => {
    if (isDeleting) return;

    setIsDeleting(true);
    try {
      await deleteForm(id);
      
      toast.success(`"${title}" has been deleted`, {
        duration: 5000,
        action: {
          label: 'Undo',
          onClick: () => {
            toast.info('Form restoration coming soon');
          }
        }
      });
      
      navigate('/');
    } catch (error) {
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'An unexpected error occurred';
      
      toast.error(`Failed to delete "${title}": ${errorMessage}`);
      console.error('Delete error:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  return {
    isDeleting,
    handleDelete
  };
}