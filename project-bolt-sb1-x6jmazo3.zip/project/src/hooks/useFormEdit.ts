import { useState } from 'react';
import { useFormStore } from '../store/formStore';
import { FeedbackForm } from '../types/form';
import { validateForm } from '../utils/form';
import { toast } from '../utils/toast';

export function useFormEdit(initialForm?: FeedbackForm) {
  const [loading, setLoading] = useState(false);
  const updateForm = useFormStore(state => state.updateForm);
  
  const handleUpdate = async (formId: string, updates: Partial<FeedbackForm>) => {
    const validation = validateForm(
      updates.title || '',
      updates.description || '',
      updates.fields || []
    );

    if (!validation.valid) {
      toast.error(validation.errors[0]);
      return false;
    }

    setLoading(true);
    try {
      await updateForm(formId, updates);
      toast.success('Form updated successfully');
      return true;
    } catch (error) {
      toast.error('Failed to update form');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    handleUpdate,
    initialData: initialForm
  };
}