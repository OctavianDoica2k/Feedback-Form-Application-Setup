export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      forms: {
        Row: {
          id: string
          title: string
          description: string | null
          category: string
          fields: Json
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          category: string
          fields: Json
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          category?: string
          fields?: Json
          created_at?: string
        }
      }
      responses: {
        Row: {
          id: string
          form_id: string
          responses: Json
          sentiment: string
          created_at: string
        }
        Insert: {
          id?: string
          form_id: string
          responses: Json
          sentiment: string
          created_at?: string
        }
        Update: {
          id?: string
          form_id?: string
          responses?: Json
          sentiment?: string
          created_at?: string
        }
      }
    }
  }
}