export interface FormField {
  id: string;
  type: 'text' | 'textarea' | 'select' | 'radio' | 'checkbox';
  label: string;
  options?: string[];
  required: boolean;
}

export interface FeedbackForm {
  id: string;
  title: string;
  description: string;
  fields: FormField[];
  category: string;
  createdAt: string;
}

export interface FeedbackResponse {
  id: string;
  formId: string;
  responses: Record<string, any>;
  sentiment: 'positive' | 'negative' | 'neutral';
  createdAt: string;
}