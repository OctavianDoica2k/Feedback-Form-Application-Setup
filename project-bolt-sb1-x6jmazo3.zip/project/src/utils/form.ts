import { FormField, FeedbackForm } from '../types/form';

export function validateFormFields(fields: FormField[]): boolean {
  return fields.every(field => {
    // Basic validation
    if (field.label.length < 3) return false;
    
    // Validate options for select and radio fields
    if (['select', 'radio'].includes(field.type)) {
      return field.options && field.options.length >= 2;
    }
    
    return true;
  });
}

export function createNewField(): FormField {
  return {
    id: crypto.randomUUID(),
    type: 'text',
    label: '',
    required: false
  };
}

export function createNewForm(
  title: string,
  description: string,
  category: string,
  fields: FormField[]
): FeedbackForm {
  return {
    id: crypto.randomUUID(),
    title,
    description,
    category,
    fields,
    createdAt: new Date().toISOString()
  };
}

export function validateForm(
  title: string,
  description: string,
  fields: FormField[]
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (title.length < 3) {
    errors.push('Title must be at least 3 characters long');
  }

  if (description.length < 10) {
    errors.push('Description must be at least 10 characters long');
  }

  if (fields.length === 0) {
    errors.push('Form must have at least one field');
  }

  fields.forEach((field, index) => {
    if (field.label.length < 3) {
      errors.push(`Field ${index + 1}: Label must be at least 3 characters long`);
    }

    if (['select', 'radio'].includes(field.type)) {
      if (!field.options || field.options.length < 2) {
        errors.push(`Field ${index + 1}: Select and Radio fields must have at least 2 options`);
      }
    }
  });

  return {
    valid: errors.length === 0,
    errors
  };
}