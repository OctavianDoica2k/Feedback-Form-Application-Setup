import { FeedbackForm } from '../types/form';

const SENTIMENT_FIELD_INDICATORS = [
  'satisfaction',
  'rating',
  'experience',
  'recommend',
  'quality',
  'sentiment'
];

export function getSentimentFromResponse(form: FeedbackForm, responses: Record<string, any>): 'positive' | 'negative' | 'neutral' {
  // Find sentiment-related fields
  const sentimentFields = form.fields.filter(field => {
    const labelLower = field.label.toLowerCase();
    return SENTIMENT_FIELD_INDICATORS.some(indicator => labelLower.includes(indicator));
  });

  if (!sentimentFields.length) {
    return 'neutral';
  }

  // Analyze each sentiment field
  const sentiments = sentimentFields.map(field => {
    const response = responses[field.id];
    
    if (!response) {
      return 'neutral';
    }

    // Handle different field types
    switch (field.type) {
      case 'select':
      case 'radio':
        return getSentimentFromOption(response);
      case 'checkbox':
        return response ? 'positive' : 'negative';
      default:
        return 'neutral';
    }
  });

  // Calculate overall sentiment
  const counts = {
    positive: sentiments.filter(s => s === 'positive').length,
    negative: sentiments.filter(s => s === 'negative').length,
    neutral: sentiments.filter(s => s === 'neutral').length
  };

  if (counts.positive > counts.negative && counts.positive > counts.neutral) {
    return 'positive';
  }
  if (counts.negative > counts.positive && counts.negative > counts.neutral) {
    return 'negative';
  }
  return 'neutral';
}

function getSentimentFromOption(value: string): 'positive' | 'negative' | 'neutral' {
  const positiveResponses = [
    'excellent',
    'very satisfied',
    'satisfied',
    'good',
    'yes',
    'definitely',
    '5',
    '4'
  ];

  const negativeResponses = [
    'poor',
    'very dissatisfied',
    'dissatisfied',
    'bad',
    'no',
    '1',
    '2'
  ];

  const valueLower = value.toLowerCase();

  if (positiveResponses.some(r => valueLower.includes(r))) {
    return 'positive';
  }
  if (negativeResponses.some(r => valueLower.includes(r))) {
    return 'negative';
  }
  return 'neutral';
}