import type { FeedbackForm, FeedbackResponse } from '../types/form';
import type { Database } from '../types/supabase';

type DbForm = Database['public']['Tables']['forms']['Insert'];
type DbResponse = Database['public']['Tables']['responses']['Insert'];

export function mapFormToDb(form: Partial<FeedbackForm>): DbForm {
  return {
    id: form.id,
    title: form.title!,
    description: form.description,
    category: form.category!,
    fields: form.fields!,
    created_at: form.createdAt
  };
}

export function mapDbToForm(dbForm: Database['public']['Tables']['forms']['Row']): FeedbackForm {
  return {
    id: dbForm.id,
    title: dbForm.title,
    description: dbForm.description || '',
    category: dbForm.category,
    fields: dbForm.fields as any,
    createdAt: dbForm.created_at
  };
}

export function mapResponseToDb(response: FeedbackResponse): DbResponse {
  return {
    id: response.id,
    form_id: response.formId,
    responses: response.responses,
    sentiment: response.sentiment,
    created_at: response.createdAt
  };
}

export function mapDbToResponse(dbResponse: Database['public']['Tables']['responses']['Row']): FeedbackResponse {
  return {
    id: dbResponse.id,
    formId: dbResponse.form_id,
    responses: dbResponse.responses as any,
    sentiment: dbResponse.sentiment as 'positive' | 'negative' | 'neutral',
    createdAt: dbResponse.created_at
  };
}