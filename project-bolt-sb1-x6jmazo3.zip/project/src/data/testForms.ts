import { FormField } from '../types/form';

// Sample form fields
const customerServiceFields: FormField[] = [
  {
    id: crypto.randomUUID(),
    type: 'select',
    label: 'How satisfied were you with our service?',
    required: true,
    options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied']
  },
  {
    id: crypto.randomUUID(),
    type: 'textarea',
    label: 'What could we improve?',
    required: true
  },
  {
    id: crypto.randomUUID(),
    type: 'radio',
    label: 'Would you recommend us to others?',
    required: true,
    options: ['Yes, definitely', 'Maybe', 'No']
  }
];

const productFeedbackFields: FormField[] = [
  {
    id: crypto.randomUUID(),
    type: 'text',
    label: 'Which product did you purchase?',
    required: true
  },
  {
    id: crypto.randomUUID(),
    type: 'radio',
    label: 'How would you rate the quality?',
    required: true,
    options: ['Excellent', 'Good', 'Average', 'Poor']
  },
  {
    id: crypto.randomUUID(),
    type: 'textarea',
    label: 'Additional comments',
    required: false
  }
];

export const testForms = [
  {
    id: crypto.randomUUID(),
    title: 'Customer Service Feedback',
    description: 'Help us improve our customer service by sharing your experience',
    category: 'Service',
    fields: customerServiceFields,
    created_at: new Date().toISOString()
  },
  {
    id: crypto.randomUUID(),
    title: 'Product Feedback',
    description: 'Share your thoughts about our products',
    category: 'Product',
    fields: productFeedbackFields,
    created_at: new Date().toISOString()
  }
];