import { supabase } from '../lib/supabase';
import { testForms } from './testForms';
import { mapFormToDb } from '../utils/mappers';

export async function seedTestData() {
  try {
    // Check if forms already exist
    const { data: existingForms } = await supabase
      .from('forms')
      .select('id')
      .limit(1);

    // Only seed if no forms exist
    if (!existingForms?.length) {
      const dbForms = testForms.map(mapFormToDb);
      
      const { error } = await supabase
        .from('forms')
        .insert(dbForms);

      if (error) throw error;
      console.log('Test data seeded successfully');
    } else {
      console.log('Forms already exist, skipping seed');
    }
  } catch (error) {
    console.error('Error seeding test data:', error);
  }
}